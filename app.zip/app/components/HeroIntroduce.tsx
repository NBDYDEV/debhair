import React from "react";
import { getHomeData } from "../lib/api";
import { MediaPlayer } from "./MediaPlayer";

const HeroIntroduce = async () => {
    const heroData = await getHomeData();
    const title = heroData?.introduce_title;
    const text = heroData?.introduce_text;
    const videoUrl = heroData?.introduce_vid?.url;

    const fullVideoUrl =
        "https://api.netbazis.com/uploads/Debhair_DEB_Hair_Clinic_Hajbeueltetesi_klinika_a8aa8a3836.mp4";

    return (
        <section className="bg-white py-16 md:py-20 lg:py-24 overflow-hidden">
            <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div
                    className="
                        flex flex-col
                        gap-12
                        lg:grid lg:grid-cols-2 lg:items-center lg:gap-20
                    "
                >
                    {/* VIDEO */}
                    <div className="w-full relative">
                        <div className="relative rounded-3xl overflow-hidden border-4 border-primarydark shadow-2xl aspect-video lg:aspect-[4/3] w-full">
                            <MediaPlayer src={fullVideoUrl} />
                        </div>
                    </div>

                    {/* SZÖVEG */}
                    <div className="w-full flex flex-col gap-6 text-left">
                        <div className="flex items-center gap-2 text-gray-500 text-sm font-bold uppercase tracking-wider">
                            <span className="w-2 h-2 rounded-full bg-primarydark/50"></span>
                            <span>Bemutatkozás</span>
                        </div>

                        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-rem font-extrabold text-primarydark leading-tight max-w-[36ch] sm:max-w-prose">
                            Prémium hajbeültetés{" "}
                            <span className="relative inline-block">
                                <span className="relative z-10 italic font-lora font-bold">
                                    luxus
                                </span>
                                <span className="absolute bottom-[0.0625rem] left-0 w-full h-2 md:h-3 bg-secondary/70 -z-0 rounded-sm"></span>
                            </span>{" "}
                            környezetben
                        </h2>

                        <div
                            className="
                                flex flex-col gap-4
                                text-gray-600
                                text-sm sm:text-base lg:text-lg
                                leading-relaxed
                                font-rem
                                max-w-[36ch]
                                sm:max-w-prose
                            "
                        >
                            {text}
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default HeroIntroduce;
